import { AuthProvider } from "./features/auth/context/AuthContext";
import { AppRouter } from "./routes/AppRouter";

const App = () => {
  return (
    <AuthProvider>
      <AppRouter />
    </AuthProvider>
  );
};

export default App;
